@extends('frontend.layouts.app')
	
@section('title', app_name())

@section('content')

<!-- ======= itbanner Section ======= -->

<div class="inner-section">
<section class="ad-sec-google">
	<div class="container-fluid">
		<div class="ad-google">
			  {{-- <img src="{{ url('img/add-ggogle.PNG') }}" alt=""> --}}
         <div class="ad-google_area">
        @php
        $googleads_header= App\Models\Googlead::where('status','1')->orderBy('id')->where('title', 'hoempage-ads-header-horizontal')->get();
          //echo '<pre>'; print_r($googleads_header);die();
        @endphp
          @foreach ($googleads_header as $adshere)
          <?php echo '<center class="ads-header">'.$adshere->adsensecode.'</center>';  ?>
          @endforeach
        </div>     
		    
    </div>
	</div>
</section>


    <section id="itbanner" class="upcoming-match-list" style="background: url(./img/team-bg.png);">

		<div class="container">
			<h2 class="border-line">Upcoming Matches</h2>
			 <div id="owl-demo">
				
        <?php $fixtures = DB::table('fixtures')->get();?>
						@foreach ($fixtures as $fixture)	
			 <div class="item">
			    <div class="col-md-12">
				     <div class="team-match-box">
				     	  <h4>{{ $fixture->league_name }}</h4>
				     	    <ul>
				     	  	  <li><div class="team-logo"><img src="{{ $fixture->team_home_logo }}"></div>{{ $fixture->team_home_name }}</li>
				     	  	  <li><div class="team-dippend">{{ $fixture->date }} <span>VS</span></div></li>
				     	  	  <li><div class="team-logo"><img src="{{ $fixture->team_away_logo }}"></div>{{ $fixture->team_away_name }}</li>
				     	    </ul>
				     	    <h5>{{ $fixture->venue_name }}</h5>
				     	</div>	
			    </div> 
			  </div>
				@endforeach
			   
		    </div>
		   <a class="btn btn-info float-right" href="{{ url('fixtures') }}">Show All Matches</a>    
    </section>
    </div>
</div>

<section id="wallchart" class="wallchart-bg" style="background: url(./img/team-match-bg.png);">

  

<div class="container-fluid">
  <div class="row">
          
          <div class="col-md-8">
            <div class="pageHeader-v pageHeaderLatestResults">
              <h2>Football Matches Results </h2>
              <div class="toolbar headControls">
                {{-- <img src="img/btn-toolbar-spr.png" alt=""> --}}
              </div>
            </div>

          
            @if ($leagues_new->count() > 0 )
            @if(isset($leagues_new) && !empty($leagues_new))
            @foreach ($leagues_new as $myleague)
          
            <div class="table-outer">
                <div class="table-responsive">
                 <table id="table" class="table soccerGrid homeMatchGrid">
                  <tbody>
                      <tr class="headRow">
                        <td colspan="12">
                         <div class="headlineGroop"><h3>{{ $myleague->league_name }} </h3><h4> </h4></div>
                        </td>
                      </tr>
                  </tbody>
                   
                   <tbody>
                      <tr class="table-primary">
                        <td><strong class="ml-4">Date</strong></td>
                        <td><strong>Status</strong></td>
                        <td><strong>Home Team</strong></td>
                        <td><strong>Result</strong></td>
                        <td><strong>Away Team</strong></td>
                      </tr>

                    
                       <tr class="match">
                        
                        <td class="first" style="">
                          <div class="ml-4">{{ date('d-m-Y', strtotime($myleague->date)) }}</div>
                        </td>

                        
                        <td class="dateTime">
                          
                        <span class="time">{{ $myleague->status_short }}</span>
                          <span class="star-re">
                            <i class="fas fa-info-circle" onclick="myFunction()"></i>
                        </span>
                      </td>


                        
                        {{-- <td class="finished">
                         <span><i class="fas fa-info-circle" ></i></span>
                        </td> --}}
                          <td>{{ $myleague->team_home_name }}</td>
                          <td>{{$myleague->goals_home}}&nbsp;&nbsp;-&nbsp;&nbsp;{{$myleague->goals_away}}</td>
                          <td>{{ $myleague->team_away_name }}</td>
                        </tr>
                     
                  </tbody>
                </table>
              </div>
               {{--  <div class="Result_dop_outer " id="myDIV" style="display: none;">
                  <h6>RESULT</h6>
                  <div class="score_team_outer">
                    <div class="score_team_logo">
                      <img src="img/800.png" alt="">
                      </div>
                      <div class="canter_text_box">
                         <p class="score clearfix"><span class="teamA"> Brentford <em>1</em></span><em class="separator">-</em><span class="teamB"><em>2</em> Leicester </span>
                         </p>

                         <p class="stats"><span title="Half-time scoreBrentford 0 - 1 Leicester"> HT <em>0</em> - <em>1</em></span><span title="Full-time score Brentford 1 - 2 Leicester"> FT <em>1</em> - <em>2</em></span>&nbsp; </p>
                      </div>
                      <div class="score_team_logo">
                      <img src="img/800.png" alt="">
                    </div>
                  </div>

                  <div class="mathias_jorgensen_outer">
                    <div class="mathias_jorgensen">
                      <p><a href="#">Mathias Jorgensen</a> (60)</p>
                       <p>&nbsp; &nbsp; &nbsp; &nbsp;</p>
                    </div>
                     <div class="mathias_jorgensen tielemans">
                      <p><a href="#">Youri Tielemans</a> (14)</p>
                      <p><a href="#">James Maddison</a> (74)</p>
                    </div>
                  </div>

                 <div class="row mt-4">
                   <div class="col-md-5">
                      <div class="team-name-tabel">
                    <table class="table table-striped">
                      <tbody>
                        <tr>
                          <th scope="row" class="colA">D Raya</th>
                          <td>(G)</td>
                          <td>1</td>
                          <td></td>
                        </tr>
                        <tr>
                          <th scope="row" class="colA">R Henry</th>
                          <td>(D)</td>
                          <td>3</td>
                          <td></td>
                        </tr>
                        <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td> <img src="img/yellow.png" alt=""></td>
                        </tr>
                         <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td></td>
                        </tr>
                         <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td></td>
                        </tr>
                         <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td> <img src="img/yellow.png" alt=""></td>
                        </tr>
                        <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td></td>
                        </tr>
                        <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td></td>
                        </tr>
                        <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td></td>
                        </tr>
                        <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td></td>
                        </tr>
                         <tr>
                          <th scope="row" class="colA">(45) E Pinnock</th>
                          <td>(D)</td>
                          <td>5</td>
                          <td></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <div class="col-md-2 progress-top">
                  <div class="progress-box">
                  <label for="customRange1" class="form-label">POSSESSION %</label>
                    <input type="range" class="form-range" id="customRange1">
                  </div>
                  <div class="progress-box">
                  <label for="customRange1" class="form-label">POSSESSION %</label>
                    <input type="range" class="form-range" id="customRange1">
                  </div>
                  <div class="progress-box">
                  <label for="customRange1" class="form-label">POSSESSION %</label>
                    <input type="range" class="form-range" id="customRange1">
                  </div>
                </div>
                 <div class="col-md-5">
                      <div class="team-name-tabel">
                    <table class="table table-striped">
                      <tbody>
                        <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td><img src="img/yellow.png" alt=""></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                        <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>
                         <tr>
                          <td></td>
                           <td>1</td>
                          <td>(G)</td>
                           <th scope="row" class="colA-right">D Raya</th>
                        </tr>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="">
                <div class="matchNoteWrapper">
                  <p class="matchNote">
                    <span class="noteTitle">REFEREE:</span>
                    <a href="#" class="bullet"><i class="fa fa-angle-double-right" aria-hidden="true"></i>Simon Hooper</a> &nbsp;&nbsp; <span class="noteTitle">STADIUM:</span> Brentford Community Stadium </p>
                  </div>
              </div>
              </div> --}}


            </div>

          @endforeach
          @endif
          @endif

          {!! $leagues_new->links('vendor.pagination.custom') !!}     
          
          </div>


            <div class="col-md-4">
              <div class="row">
                <div class="col-md-12">
                  <div class="news-video mb-10">
                    {{-- <img src="{{ url('img/frontend/ads-competition-page.PNG') }}"> --}}
                    {{-- <span><i class="fas fa-play"></i></span> --}}
                    
                    @php
                    $googleads= App\Models\Googlead::where('status','1')->orderBy('id')->where('title', 'hoempage-ads-vertical')->get();
                    //echo '<pre>'; print_r($googleads);die();
                    @endphp

                    @foreach ($googleads as $adshere)
                    <?php echo $adshere->adsensecode;  ?>   
                    @endforeach
                  </div> 
                </div> 
              </div>
            </div>
         
      </div>
</section>

                  




<div class="add-here">
  <div class="container">
     <div class="add-img">
        {{-- <img src="{{ asset('img/add-banner.png') }}"> --}}
        @php
          $googleads_footer= App\Models\Googlead::where('status','1')->orderBy('id')->where('title', 'hoempage-ads-footer-horizontal')->get();
          //echo '<pre>'; print_r($googleads_footer);die();
          @endphp

          @foreach ($googleads_footer as $adshere)
          <?php echo '<center>'.$adshere->adsensecode.'</center>';  ?>   
        @endforeach
     </div>
  </div>
</div>



{{-- <div id="add-section">
	 <div class="container">
	 	<div class="team-bg" style="background: url(./img/team.png);">
	 	  <div class="newsletter-box">
	 	  	<div class="newsleter-title">
	 	  	   <h4>SUBSCRIBE OUR NEWSLETTER</h4>
	 	  	   <p>Subscribe to our newsletter for getting regular updates.</p>
	 	    </div>
	 	  	<div class="email-box">
	 	  	   <input type="text" class="form-control" placeholder="Email Address">
	 	  	   <button class="btn subscribe-btn">Subscribe</button>
	 	  	</div>
	 	  </div>
	 	</div>
	 </div>
</div> --}}


</script>

@endsection



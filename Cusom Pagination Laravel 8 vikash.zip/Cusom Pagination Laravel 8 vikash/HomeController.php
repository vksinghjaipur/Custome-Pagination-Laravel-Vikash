<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
// use App\Models\League;
use App\Models\Fixture;
use App\Models\Guessfixture;
/**
 * Class HomeController.
 */
class HomeController extends Controller
{
    /**
     * @return \Illuminate\View\View
     */
  

    public function index()
    {
       // $leagues_new=League::with('fixturesleg')->get();
        $leagues_new=Guessfixture::get();
        //echo '<pre>'; print_r($leagues_new); die();
        //$leagues_new = League::latest()->paginate(20);
        $leagues_new = Guessfixture::latest()->paginate(10);
        return view('frontend.index', compact('leagues_new'));

        
    }

    public function getGooglecode()
    {
        $googleads = DB::table('googleads')->where('id', 1)->get();
        //print_r($googleads);die();
        return view('frontend.index', compact('googleads'));
    }

   

}
